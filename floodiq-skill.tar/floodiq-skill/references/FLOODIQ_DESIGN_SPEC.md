# FloodIQ — Design & Build Specification

> **Purpose**: Hand this document to Claude Code (or any AI coding assistant) to build the FloodIQ application from scratch. It contains the complete product vision, UX specification, architecture, data sources, agent design, and deployment plan.

---

## 1. Product overview

**FloodIQ** is a multi-agent AI flood risk advisor. A user enters any US address and receives a personalized "risk dossier" — a comprehensive flood risk assessment assembled by a team of specialized Gemma 4 agents working in parallel. The output explains what insurance the user actually needs, why FEMA's assessment may be misleading, and what actions they can take today.

**Hackathon target**: Gemma 4 Good Hackathon on Kaggle (deadline May 18, 2026). Track: Global Resilience. Prize targets: Main Track + Impact Track.

**Core insight**: FEMA flood maps measure riverine flooding. In flat cities like Chicago with combined sewer systems, most flooding is sewer backup — which FEMA doesn't map. People outside FEMA flood zones don't buy flood insurance, then get devastated. FloodIQ bridges this gap.

---

## 2. UX specification

### 2.1 Design philosophy

- **Minimal input, maximum insight.** The user does ONE thing: enter an address. Everything else is handled by AI agents.
- **Transparency over magic.** Show the agents working. Show what data they found. Show their reasoning. This builds trust and is the "wow factor" for the hackathon demo.
- **Actionable over informational.** Every section ends with something the user can DO — buy insurance, call a number, install a valve, disconnect a downspout.
- **No chatbot.** This is NOT a chat interface. It's a structured report generator with an agent orchestration layer visible to the user.

### 2.2 Three screens

The app has exactly three states:

#### Screen 1: Search (landing page)

```
Layout:
- Centered content, max-width 640px
- Headline: "Know your real flood risk"
- Subtext: "Enter any US address. Our AI team investigates FEMA zones,
  local sewer data, weather forecasts, and recent flood news — then
  tells you what insurance you actually need."
- Search input: large, prominent, with a search icon
  - Placeholder: "Enter an address, e.g. 4521 S Drexel Blvd, Chicago"
  - On submit → geocode the address → transition to Screen 2
- Example chips below the input (clickable):
  - "Albany Park, Chicago"
  - "Houston Heights, TX"
  - "Hoboken, NJ"
  - "Miami Beach, FL"
  - Clicking a chip fills the input and triggers the search
- Footer: small text explaining data sources are public/free

Visual tone:
- Clean, editorial, lots of whitespace
- Single accent color (deep blue) for the search input focus state
- No illustrations, no icons, no hero images — just type and space
```

#### Screen 2: Agents working (loading/progress state)

```
Layout:
- Address displayed at top: "Investigating 4521 S Drexel Blvd, Chicago IL 60653"
- Agent status bar: horizontal row of agent pills, each showing:
  - A small dot (gray=idle, blue+pulsing=working, teal=done)
  - Agent name
  - Agents: FEMA expert, 311 analyst, Weather analyst, News scout,
    Archivist, Risk analyst, Advisor
- Live activity feed below the agent bar:
  - As each agent completes, a line appears:
    "FEMA expert — found flood zone X (minimal risk), but this is
     misleading for Chicago..."
    "311 analyst — found 23 basement flooding reports within 500m
     since 2020"
    "Weather analyst — checking USGS stream gauge and NOAA
     precipitation outlook..."
  - Each line shows the agent name in its status color + a short
    finding summary
- When all agents complete → auto-transition to Screen 3

Implementation:
- The agents work via the backend. The frontend polls or uses SSE
  (server-sent events) to get real-time agent status updates.
- Each agent status update includes: agent_name, status (idle/working/done),
  and a short finding_summary string.
- The transition to Screen 3 happens when the orchestrator agent
  returns the final compiled dossier.
```

#### Screen 3: Risk dossier (the report)

```
Layout:
- Full-width report, max-width 680px, clean vertical scroll
- Components appear in this order:

1. RISK HEADER
   - Left: circular risk score (0-100) with color coding:
     - 0-30 green, 31-60 amber, 61-100 coral/red
   - Right: headline + address + key tags (sewer type, FEMA zone)
   - Example: "72 — High urban flood risk — despite FEMA saying 'minimal'"

2. THE FEMA GAP (collapsible section)
   - Icon: coral warning icon
   - Badge: "Misleading" (coral)
   - Body: plain-language explanation of WHY FEMA says minimal but
     the actual risk is high. Mentions sewer backup, combined sewers,
     311 history.
   - Probability bar: visual bar showing "probability of at least one
     basement flood over a 30-year mortgage" with percentage
   - The math: P = 1 − (1 − AEP)^n
     But presented as a simple bar, not a formula.

3. LOCAL INFRASTRUCTURE (collapsible section)
   - Icon: blue water icon
   - Key-value stat rows:
     - Sewer type: Combined / Separate / Unknown
     - Sewer overwhelm threshold: X in/hr
     - Impervious surface: ~X%
     - Deep Tunnel (TARP) coverage: Yes/No + which system
     - 311 flood reports (500m radius, last 5yr): count
     - Nearest USGS stream gauge: name + current discharge

4. INSURANCE GUIDANCE (collapsible section)
   - Icon: purple dollar icon
   - Badge: "Personalized" (teal)
   - Intro text explaining whether federal law requires flood insurance
     for this zone, and why coverage is still recommended.
   - 2x2 grid of insurance option cards:
     a. NFIP (Preferred Risk or Standard, depending on zone)
        - Approx annual cost
        - Coverage limits
        - Why relevant for this address
     b. Private excess flood
        - What it fills beyond NFIP
     c. Parametric (FloodFlash-style)
        - How sensor triggers work
        - Why instant payout matters
     d. Sewer backup rider
        - Add-on to existing homeowners policy
        - Cheapest, most targeted protection for urban flooding
   - ONE card gets a "Recommended" badge based on the risk profile

5. YOUR ACTION PLAN (collapsible section)
   - Icon: green plus icon
   - Numbered list of 4-6 specific actions, prioritized by
     impact and cost:
     1. Disconnect downspouts (free, DIY)
     2. Install backwater valve ($1K-2.5K, mention city programs)
     3. Add sewer backup rider (~$50/yr)
     4. Get NFIP policy (with estimated cost)
     5. Get a sewer camera inspection ($150-300)
     6. Check MWRD cost-share programs
   - Each action has: bold title, 1-2 sentence explanation,
     cost estimate, and a phone number or URL where applicable

6. RECENT LOCAL FLOOD NEWS (collapsible section)
   - Icon: amber newspaper icon
   - 3-5 recent news articles from GDELT related to flooding
     in the user's area
   - Each item: date, headline, source

7. METHODOLOGY FOOTER
   - Small text listing all data sources with links
   - "Powered by Gemma 4 — all analysis runs locally"
   - Disclaimer: "This is not financial or insurance advice."
```

### 2.3 Visual design system

```
Typography:
- Headlines: DM Sans (Google Fonts), weight 500
- Body: DM Sans, weight 400
- Monospace (stats): JetBrains Mono or DM Mono
- All sentence case, never Title Case or ALL CAPS

Colors:
- Background: white (#FFFFFF) / dark mode: #1A1A1A
- Text primary: #1A1A1A / dark: #F0F0F0
- Text secondary: #6B7280
- Accent blue: #185FA5
- Risk score colors:
  - Low (0-30): #0F6E56 (teal)
  - Medium (31-60): #BA7517 (amber)
  - High (61-100): #D85A30 (coral)
- Section icon backgrounds: use light tints of each color
- Agent status: idle=#9CA3AF, working=#185FA5 (pulse), done=#0F6E56

Spacing:
- Sections: 1.25rem gap between
- Inside sections: 16px padding
- Cards grid: 10px gap
- Content max-width: 680px, centered

Components:
- Sections: 0.5px border, border-radius 12px, white background
- Section headers: clickable to collapse/expand, with icon + title + optional badge
- Stat rows: label left, value right, 0.5px border-bottom divider
- Insurance cards: 0.5px border, 12px padding, border-radius 8px
- Recommended card: 1.5px teal border
- Probability bar: 8px height, rounded, background track + colored fill
- Agent pills: rounded-full, 11px text, dot + name
- Risk score circle: 64px, centered number

Animations:
- Agent dot pulse: opacity 1→0.3→1, 1s infinite (only while "working")
- Section expand/collapse: height transition 200ms ease
- Report sections: stagger-fade-in on initial load (50ms delay per section)
- Probability bar: width transition 1s ease on mount
- Screen transitions: simple opacity crossfade 300ms
```

### 2.4 Responsive behavior

```
- Desktop (>768px): max-width 680px centered
- Mobile (<768px): full-width with 16px horizontal padding
- Insurance cards: 2x2 grid on desktop, single column on mobile
- Agent bar: wraps to 2 rows on mobile
- All sections are full-width on mobile
- Search input: 100% width always
```

---

## 3. Architecture

### 3.1 Stack

```
Frontend: React 18 + TypeScript + Vite + Tailwind CSS
Backend:  Python 3.11 + FastAPI
LLM:      Gemma 4 via OpenRouter free API (primary)
                   via Google AI Studio free tier (fallback)
Hosting:  Frontend → Cloudflare Pages (free)
          Backend  → Hugging Face Spaces, Docker SDK (free)
```

### 3.2 Project structure

```
floodiq/
├── frontend/
│   ├── src/
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   ├── components/
│   │   │   ├── SearchScreen.tsx
│   │   │   ├── AgentsScreen.tsx
│   │   │   ├── DossierScreen.tsx
│   │   │   ├── RiskHeader.tsx
│   │   │   ├── FemaGapSection.tsx
│   │   │   ├── InfrastructureSection.tsx
│   │   │   ├── InsuranceSection.tsx
│   │   │   ├── ActionPlanSection.tsx
│   │   │   ├── NewsSection.tsx
│   │   │   ├── AgentStatusBar.tsx
│   │   │   ├── CollapsibleSection.tsx
│   │   │   ├── ProbabilityBar.tsx
│   │   │   └── InsuranceCard.tsx
│   │   ├── hooks/
│   │   │   ├── useFloodAssessment.ts    # SSE connection to backend
│   │   │   └── useGeocoder.ts           # Address → lat/lon
│   │   ├── types/
│   │   │   └── index.ts                 # TypeScript interfaces
│   │   └── styles/
│   │       └── index.css
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.ts
│   └── package.json
├── backend/
│   ├── app/
│   │   ├── main.py                      # FastAPI app + CORS
│   │   ├── api/
│   │   │   ├── assess.py                # POST /api/assess — main endpoint
│   │   │   └── health.py                # GET /api/health
│   │   ├── agents/
│   │   │   ├── orchestrator.py          # Routes to specialist agents
│   │   │   ├── fema_agent.py            # FEMA NFHL lookup
│   │   │   ├── local_agent.py           # Chicago 311 + sewer data
│   │   │   ├── weather_agent.py         # USGS + NOAA + Open-Meteo
│   │   │   ├── news_agent.py            # GDELT recent flood news
│   │   │   ├── archive_agent.py         # NOAA Storm Events history
│   │   │   ├── risk_agent.py            # Probability computation + synthesis
│   │   │   └── advisor_agent.py         # Insurance + action plan generation
│   │   ├── tools/
│   │   │   ├── fema.py                  # FEMA NFHL ArcGIS REST client
│   │   │   ├── chicago_311.py           # Socrata SODA API client
│   │   │   ├── usgs.py                  # USGS Water Services client
│   │   │   ├── noaa.py                  # NOAA NWS forecast client
│   │   │   ├── open_meteo.py            # Open-Meteo flood API client
│   │   │   ├── gdelt.py                 # GDELT news search client
│   │   │   ├── geocoder.py              # Nominatim geocoding
│   │   │   └── elevation.py             # USGS 3DEP elevation
│   │   ├── llm/
│   │   │   ├── client.py                # OpenRouter / Google AI Studio client
│   │   │   └── prompts.py               # System prompts per agent
│   │   └── models/
│   │       └── schemas.py               # Pydantic models for all data
│   ├── Dockerfile
│   ├── requirements.txt
│   └── README.md                        # HF Spaces frontmatter
└── README.md                            # Project README for GitHub
```

### 3.3 Data flow

```
User enters address
      │
      ▼
Frontend: POST /api/assess { address: "4521 S Drexel Blvd, Chicago" }
      │                      (returns SSE stream)
      ▼
Backend: Geocode address → (lat, lon)
      │
      ▼
Orchestrator agent (Gemma 4 31B via OpenRouter)
      │
      ├─── FEMA agent ──→ FEMA NFHL REST API ──→ flood zone, BFE
      │        │
      │        └──→ SSE: { agent: "fema", status: "done", summary: "Zone X..." }
      │
      ├─── Local agent ──→ Chicago 311 SODA API ──→ flood reports count
      │        │         ──→ (sewer type from static lookup or MWRD)
      │        └──→ SSE: { agent: "local", status: "done", summary: "23 reports..." }
      │
      ├─── Weather agent ─→ USGS + NOAA + Open-Meteo ──→ discharge, forecast
      │        └──→ SSE: { agent: "weather", status: "done", summary: "..." }
      │
      ├─── News agent ────→ GDELT API ──→ recent flood articles
      │        └──→ SSE: { agent: "news", status: "done", summary: "..." }
      │
      ├─── Archive agent ──→ NOAA Storm Events ──→ historical events
      │        └──→ SSE: { agent: "archive", status: "done", summary: "..." }
      │
      ▼ (all data collected)
      │
      ├─── Risk analyst agent (Gemma 4 26B, thinking=ON)
      │        │
      │        └──→ Computes: risk score, AEP probability, FEMA gap analysis
      │             Uses Gemma 4 reasoning to synthesize all data points
      │             SSE: { agent: "risk", status: "done", summary: "Risk 72/100..." }
      │
      └─── Advisor agent (Gemma 4, thinking=OFF)
               │
               └──→ Generates: insurance recommendations, action plan,
                    plain-language explanations, localized to region
                    SSE: { agent: "advisor", status: "done", summary: "..." }
      │
      ▼
Final SSE event: { type: "complete", dossier: { ... full report JSON } }
      │
      ▼
Frontend renders the Risk Dossier (Screen 3)
```

---

## 4. Agent specifications

### 4.1 FEMA expert agent

```
Role: Look up the official FEMA flood zone designation for the address.
Tools: FEMA NFHL ArcGIS REST API
Input: (lat, lon)
Output: {
  flood_zone: "X" | "AE" | "VE" | "A" | etc.,
  zone_description: "...",
  base_flood_elevation: number | null,
  is_sfha: boolean,  // Special Flood Hazard Area
  requires_insurance: boolean,  // federally mandated
  map_panel: string,
  map_date: string
}
System prompt excerpt:
  "You are a FEMA flood zone expert. Given coordinates, use the FEMA NFHL
   tool to look up the flood zone. Return the zone, whether it's an SFHA,
   whether federal law requires flood insurance, and the map panel date.
   Note if the map is more than 5 years old — it may not reflect current risk."
```

### 4.2 Local infrastructure agent (311 analyst)

```
Role: Investigate local flooding history and infrastructure.
Tools: Chicago 311 SODA API, static sewer-type lookup
Input: (lat, lon, city)
Output: {
  flood_reports_500m_5yr: number,
  flood_reports_1km_5yr: number,
  sewer_type: "combined" | "separate" | "unknown",
  sewer_overwhelm_threshold: string,
  impervious_surface_pct: number | null,
  tarp_coverage: boolean | null,
  tarp_system: string | null,
  nearest_reports: [{ date, type, distance_m }]
}
Notes:
  - For Chicago, query the 311 dataset for sr_short_code='WIB' (water in basement)
    and 'SFL' (street flooding) within a radius.
  - For non-Chicago cities, attempt to find equivalent open data portals.
    If unavailable, return null fields and note the gap.
  - Sewer type can be looked up from EPA CSO data (cities with CSOs
    have combined sewers in those areas).
```

### 4.3 Weather analyst agent

```
Role: Check current and forecast water conditions.
Tools: USGS Water Services, NOAA NWS, Open-Meteo Flood API
Input: (lat, lon)
Output: {
  usgs_nearest_gauge: { site_id, name, distance_km },
  current_discharge_cfs: number | null,
  discharge_percentile: string,  // "normal", "above normal", "flood stage"
  river_discharge_forecast_7d: [number],
  noaa_precipitation_forecast: string,
  flood_watch_active: boolean,
  flood_warning_active: boolean
}
```

### 4.4 News scout agent

```
Role: Find recent local flood news.
Tools: GDELT API
Input: (city, state, lat, lon)
Output: {
  articles: [{
    title: string,
    source: string,
    date: string,
    url: string,
    relevance_note: string  // 1-sentence summary by the agent
  }]
}
Query: GDELT Doc API with query="flooding OR basement flood OR sewer backup"
       plus the city name, filtered to last 6 months, max 5 results.
```

### 4.5 Archivist agent

```
Role: Look up historical flood/storm events for the area.
Tools: NOAA Storm Events database (bulk CSV or NCEI API), OpenFEMA disaster declarations
Input: (county, state, lat, lon)
Output: {
  storm_events_10yr: [{
    date: string,
    event_type: string,  // "Flash Flood", "Flood", "Heavy Rain"
    damage_property: string,
    description_excerpt: string
  }],
  fema_disaster_declarations: [{
    declaration_date: string,
    declaration_type: string,
    title: string
  }],
  event_count_10yr: number
}
```

### 4.6 Risk analyst agent

```
Role: Synthesize all data into a risk score and probability assessment.
LLM config: Gemma 4 26B or 31B, thinking=ON
Input: All outputs from agents 4.1-4.5
Output: {
  risk_score: number,        // 0-100
  risk_level: "low" | "medium" | "high",
  aep_estimate: number,      // Annual exceedance probability (0-1)
  mortgage_30yr_probability: number,  // P = 1-(1-AEP)^30
  fema_gap_explanation: string,       // 2-3 sentences
  key_risk_factors: [string],         // ranked list
  mitigating_factors: [string]
}
System prompt excerpt:
  "You are a flood risk analyst. You have data from FEMA, local 311 reports,
   weather services, historical storm events, and recent news. Your job is
   to synthesize this into a risk score (0-100) and estimate the annual
   exceedance probability for this specific address.

   IMPORTANT: FEMA flood zones only capture riverine/coastal flood risk.
   In cities with combined sewer systems, urban flooding (basement backup,
   street ponding) is often the dominant risk and is NOT reflected in
   FEMA zones. If the address is in a combined sewer area with significant
   311 flood history, the risk score should reflect this even if FEMA
   says 'minimal risk.'

   Use the formula P = 1 - (1 - AEP)^n to compute cumulative probability
   over a 30-year mortgage. A '100-year flood' is 1% AEP per year, which
   is 26% over 30 years. A '500-year flood' is 0.2% AEP, or 6% over 30 years.

   Think step by step. Show your reasoning."
```

### 4.7 Advisor agent

```
Role: Generate personalized insurance recommendations and action plan.
LLM config: Gemma 4, thinking=OFF (fast, direct output)
Input: Risk analyst output + all raw agent data + user context
Output: {
  insurance_required_by_law: boolean,
  insurance_recommendations: [{
    type: "nfip" | "private_excess" | "parametric" | "sewer_backup_rider",
    name: string,
    description: string,
    estimated_annual_cost: string,
    why_relevant: string,
    is_recommended: boolean
  }],
  action_plan: [{
    priority: number,
    title: string,
    description: string,
    estimated_cost: string,
    contact: string | null  // phone number or URL
  }],
  plain_language_summary: string  // 3-4 sentence overall summary
}
System prompt excerpt:
  "You are a flood insurance advisor. Based on the risk assessment,
   generate personalized insurance recommendations and a prioritized
   action plan.

   For insurance, consider:
   1. NFIP (National Flood Insurance Program) — Preferred Risk Policy
      if Zone X, Standard if SFHA. Mention coverage limits ($250K/$100K).
   2. Private excess flood — for coverage above NFIP limits.
   3. Parametric insurance (FloodFlash-style) — sensor-triggered instant
      payout. Explain how trigger depths work. Mention basis risk simply.
   4. Sewer backup rider — add-on to homeowners policy. Often $40-75/yr.
      Most cost-effective for urban basement flooding.

   For actions, prioritize by impact-to-cost ratio:
   1. Disconnect downspouts (free, DIY, biggest impact in combined sewer areas)
   2. Install backwater valve ($1K-2.5K, prevents sewer backup)
   3. Add sewer backup rider (~$50/yr)
   4. Get NFIP or private flood policy
   5. Sewer camera inspection ($150-300)
   6. Check for MWRD / city cost-share programs

   Be specific. Include phone numbers and URLs where possible.
   Write at a 5th-grade reading level. No jargon without explanation."
```

---

## 5. API endpoints

### Backend (FastAPI)

```
GET  /api/health
     Returns: { status: "ok" }

POST /api/assess
     Body: { address: string }
     Returns: SSE stream (text/event-stream)

     SSE event format:
     event: agent_update
     data: {
       "agent": "fema" | "local" | "weather" | "news" | "archive" | "risk" | "advisor",
       "status": "working" | "done" | "error",
       "summary": "Short finding description"
     }

     event: complete
     data: {
       "dossier": { ... full DossierResponse object }
     }

     event: error
     data: { "message": "Error description" }

GET  /api/geocode?q={address}
     Returns: { lat: number, lon: number, display_name: string }
     Proxy to Nominatim.
```

---

## 6. LLM integration

### OpenRouter (primary, free)

```python
import httpx

OPENROUTER_BASE = "https://openrouter.ai/api/v1"
OPENROUTER_API_KEY = os.environ["OPENROUTER_API_KEY"]  # free account key

async def call_gemma4(messages, tools=None, model="google/gemma-4-27b-it:free"):
    payload = {
        "model": model,
        "messages": messages,
        "max_tokens": 4096,
    }
    if tools:
        payload["tools"] = tools

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{OPENROUTER_BASE}/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=60,
        )
        return resp.json()
```

### Google AI Studio (fallback)

```python
# If OpenRouter is rate-limited, fall back to Google AI Studio
# Gemma 4 is available via the Gemini API free tier
import google.generativeai as genai

genai.configure(api_key=os.environ.get("GOOGLE_AI_KEY"))
model = genai.GenerativeModel("gemma-4-26b-a4b-it")
```

### Rate limit handling

```
OpenRouter free tier: ~20 RPM / 200 RPD per model
Strategy:
- Use google/gemma-4-27b-it:free for data-fetcher agents (5 parallel)
- Use google/gemma-4-31b-it:free for risk analyst (1 call, thinking=on)
- If rate-limited, fall back to Google AI Studio
- Cache responses for identical addresses (in-memory dict, cleared on restart)
```

---

## 7. Free data source API reference

### FEMA NFHL (flood zones)
```
GET https://hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer/28/query
    ?geometry={"x":{lon},"y":{lat},"spatialReference":{"wkid":4326}}
    &geometryType=esriGeometryPoint
    &inSR=4326
    &outFields=FLD_ZONE,STATIC_BFE,ZONE_SUBTY
    &returnGeometry=false
    &f=json
Auth: None
```

### Chicago 311 flooding
```
GET https://data.cityofchicago.org/resource/v6vf-nfxy.json
    ?$where=sr_short_code='WIB'
      AND created_date > '2021-01-01'
      AND within_circle(location, {lat}, {lon}, 500)
    &$limit=1000
Auth: Optional app token (works without)
```

### USGS stream gauges
```
GET https://waterservices.usgs.gov/nwis/iv/
    ?format=json
    &sites={site_id}
    &parameterCd=00060,00065
    &siteStatus=all
Auth: None
Note: Find nearest gauge with
  https://waterservices.usgs.gov/nwis/site/?format=json
  &bBox={lon-0.1},{lat-0.1},{lon+0.1},{lat+0.1}
  &siteType=ST
  &siteStatus=active
```

### NOAA NWS forecast
```
GET https://api.weather.gov/points/{lat},{lon}
    → returns forecast URL
GET {forecast_url}/forecast/hourly
Auth: None (but set User-Agent header)
```

### Open-Meteo flood
```
GET https://flood-api.open-meteo.com/v1/flood
    ?latitude={lat}&longitude={lon}
    &daily=river_discharge,river_discharge_max
    &past_days=30
Auth: None
```

### GDELT news
```
GET https://api.gdeltproject.org/api/v2/doc/doc
    ?query="basement flooding" OR "sewer backup" {city}
    &mode=ArtList
    &format=json
    &maxrecords=10
    &timespan=6m
Auth: None
```

### USGS elevation
```
GET https://epqs.nationalmap.gov/v1/json
    ?x={lon}&y={lat}&units=Meters&wkid=4326
Auth: None
```

---

## 8. Deployment

### Frontend → Cloudflare Pages
```
Build command: npm run build
Output directory: dist
Environment variable: VITE_API_URL → backend HF Space URL
```

### Backend → Hugging Face Spaces
```
SDK: Docker
App port: 8000
Dockerfile:
  FROM python:3.11-slim
  WORKDIR /app
  COPY requirements.txt .
  RUN pip install --no-cache-dir -r requirements.txt
  COPY app/ ./app/
  CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]

Environment variables (HF Space secrets):
  OPENROUTER_API_KEY=...
  GOOGLE_AI_KEY=...  (fallback)

CORS: Allow *.pages.dev and localhost:*
```

### Total cost: $0/month

---

## 9. Hackathon submission checklist

```
[ ] Working live demo at {app}.pages.dev
[ ] Public GitHub repo with clean README
[ ] YouTube video (≤3 min):
    - 0:00-0:30  The problem (500-year flood misconception, FEMA gaps)
    - 0:30-1:30  Demo: type an address, watch agents work, see dossier
    - 1:30-2:30  Technical depth: show the agent architecture, Gemma 4 usage
    - 2:30-3:00  Impact: who this helps, what's next
[ ] Kaggle Writeup (≤1,500 words):
    - Track: Global Resilience
    - Architecture explanation
    - How Gemma 4 is used (function calling, thinking mode, multi-agent)
    - Why it matters
[ ] Cover image for Kaggle writeup
[ ] Media gallery screenshots
```

---

## 10. Key technical decisions

```
1. SSE over WebSocket: simpler, one-directional (server→client), no
   connection management needed. FastAPI's StreamingResponse handles it.

2. OpenRouter over self-hosted: no GPU needed, free tier sufficient for
   demo. Fallback to Google AI Studio if rate-limited.

3. No database: everything is computed fresh per request. In-memory cache
   for identical addresses within a session. This is a hackathon demo,
   not a production system.

4. Agent orchestration in Python, not LangGraph: for a hackathon,
   simple asyncio.gather() with status callbacks is cleaner than
   adding a framework dependency. Each agent is a Python async function
   that calls tools and then calls Gemma 4 to interpret the results.

5. Tailwind CSS over custom CSS: faster to build, responsive out of the
   box, utility-first matches the clean design system.

6. Sections collapsible but all open by default: judges should see
   everything without clicking. Users can collapse sections they've read.
```
